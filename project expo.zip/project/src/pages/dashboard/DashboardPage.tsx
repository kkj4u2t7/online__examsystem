import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, CheckCircle, User, Book, AlertTriangle, ArrowUpRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam } from '../../contexts/ExamContext';
import { format } from 'date-fns';
import { motion } from 'framer-motion';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { exams, submissions, getUserExams, getUserSubmissions } = useExam();
  const [activeTab, setActiveTab] = useState<'upcoming' | 'completed'>('upcoming');

  // Get exams and submissions for the current user
  const userExams = user ? getUserExams(user.id) : [];
  const userSubmissions = user ? getUserSubmissions(user.id) : [];
  
  // For students: filter exams they haven't taken yet
  const upcomingExams = user?.role === 'student'
    ? userExams.filter(exam => 
        !userSubmissions.some(sub => sub.examId === exam.id)
      )
    : userExams;
  
  // Completed exams (for students this is submissions, for instructors it's published exams)
  const completedExams = user?.role === 'student'
    ? userSubmissions.map(sub => {
        const exam = exams.find(e => e.id === sub.examId);
        return {
          ...exam,
          submission: sub
        };
      })
    : userExams.filter(exam => exam.isPublished);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        when: "beforeChildren",
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">
          Welcome back, {user?.name}!
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">
                {user?.role === 'student' ? 'Exams Taken' : 'Exams Created'}
              </p>
              <p className="text-2xl font-bold text-gray-900">
                {user?.role === 'student' ? userSubmissions.length : userExams.length}
              </p>
            </div>
            <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-800">
              <Book size={24} />
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">
                {user?.role === 'student' ? 'Average Score' : 'Students Tested'}
              </p>
              <p className="text-2xl font-bold text-gray-900">
                {user?.role === 'student' 
                  ? userSubmissions.length > 0 
                    ? `${Math.round(userSubmissions.filter(s => s.score !== undefined)
                        .reduce((acc, sub) => acc + (sub.score || 0), 0) / 
                        userSubmissions.filter(s => s.score !== undefined).length)}%` 
                    : '0%'
                  : '42'}
              </p>
            </div>
            <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center text-green-800">
              {user?.role === 'student' 
                ? <CheckCircle size={24} />
                : <User size={24} />
              }
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Upcoming Exams</p>
              <p className="text-2xl font-bold text-gray-900">{upcomingExams.length}</p>
            </div>
            <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-800">
              <Calendar size={24} />
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-100"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Pending Review</p>
              <p className="text-2xl font-bold text-gray-900">
                {user?.role === 'student' 
                  ? userSubmissions.filter(s => !s.isGraded).length
                  : '7'}
              </p>
            </div>
            <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center text-red-800">
              <AlertTriangle size={24} />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Exams Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
        <div className="border-b border-gray-100">
          <div className="flex">
            <button
              className={`px-6 py-3 text-sm font-medium ${
                activeTab === 'upcoming'
                  ? 'text-blue-800 border-b-2 border-blue-800'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setActiveTab('upcoming')}
            >
              {user?.role === 'student' ? 'Available Exams' : 'Your Exams'}
            </button>
            <button
              className={`px-6 py-3 text-sm font-medium ${
                activeTab === 'completed'
                  ? 'text-blue-800 border-b-2 border-blue-800'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setActiveTab('completed')}
            >
              {user?.role === 'student' ? 'Completed Exams' : 'Published Exams'}
            </button>
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'upcoming' && (
            <>
              {upcomingExams.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-gray-500">No exams available at the moment.</p>
                  {user?.role === 'instructor' && (
                    <Link 
                      to="/exams/create"
                      className="mt-4 inline-block px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700 transition-colors duration-200"
                    >
                      Create New Exam
                    </Link>
                  )}
                </div>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {upcomingExams.map(exam => (
                    <motion.div 
                      key={exam.id}
                      variants={itemVariants}
                      className="border border-gray-100 rounded-lg p-4 hover:shadow-md transition-shadow duration-200"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-900">{exam.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{exam.description}</p>
                          <div className="flex items-center mt-2 text-xs text-gray-500 space-x-4">
                            <div className="flex items-center">
                              <Clock size={14} className="mr-1" />
                              {exam.duration} minutes
                            </div>
                            <div className="flex items-center">
                              <Book size={14} className="mr-1" />
                              {exam.questions.length} questions
                            </div>
                          </div>
                        </div>
                        <Link
                          to={user?.role === 'student' ? `/exams/${exam.id}` : `/exams/${exam.id}`}
                          className="px-3 py-1 bg-blue-800 text-white text-sm rounded-md flex items-center hover:bg-blue-700 transition-colors duration-200"
                        >
                          {user?.role === 'student' ? 'Take Exam' : 'View'}
                          <ArrowUpRight size={14} className="ml-1" />
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          )}

          {activeTab === 'completed' && (
            <>
              {completedExams.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-gray-500">You haven't completed any exams yet.</p>
                </div>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {completedExams.map((item: any) => (
                    <motion.div 
                      key={user?.role === 'student' ? item.submission.id : item.id}
                      variants={itemVariants}
                      className="border border-gray-100 rounded-lg p-4 hover:shadow-md transition-shadow duration-200"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-900">{item.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                          {user?.role === 'student' && (
                            <div className="flex flex-wrap items-center mt-2 text-xs space-x-4">
                              {item.submission.score !== undefined ? (
                                <div className="text-green-600 font-medium flex items-center">
                                  <CheckCircle size={14} className="mr-1" />
                                  Score: {item.submission.score}%
                                </div>
                              ) : (
                                <div className="text-amber-600 font-medium flex items-center">
                                  <Clock size={14} className="mr-1" />
                                  Awaiting Results
                                </div>
                              )}
                              <div className="text-gray-500">
                                Completed on {format(new Date(item.submission.endTime), 'MMM d, yyyy')}
                              </div>
                            </div>
                          )}
                          {user?.role === 'instructor' && (
                            <div className="flex items-center mt-2 text-xs text-gray-500 space-x-4">
                              <div className="flex items-center">
                                <Calendar size={14} className="mr-1" />
                                Created on {format(new Date(item.createdAt), 'MMM d, yyyy')}
                              </div>
                              <div className="flex items-center">
                                <Book size={14} className="mr-1" />
                                {item.questions.length} questions
                              </div>
                            </div>
                          )}
                        </div>
                        <Link
                          to={user?.role === 'student' ? `/results/${item.submission.id}` : `/exams/${item.id}`}
                          className="px-3 py-1 bg-blue-800 text-white text-sm rounded-md flex items-center hover:bg-blue-700 transition-colors duration-200"
                        >
                          {user?.role === 'student' ? 'View Results' : 'View Exam'}
                          <ArrowUpRight size={14} className="ml-1" />
                        </Link>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;