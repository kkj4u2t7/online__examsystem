import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { CheckCircle, XCircle, AlertCircle, ArrowLeft, Award, Download } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam, ExamSubmission } from '../../contexts/ExamContext';
import { motion } from 'framer-motion';

const ResultsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { exams, submissions } = useExam();
  
  const [submission, setSubmission] = useState<ExamSubmission | undefined>(undefined);
  const [exam, setExam] = useState<any>(undefined);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    if (id) {
      const sub = submissions.find(s => s.id === id);
      setSubmission(sub);
      
      if (sub) {
        const relatedExam = exams.find(e => e.id === sub.examId);
        setExam(relatedExam);
      }
      
      setLoading(false);
    }
  }, [id, submissions, exams]);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }
  
  if (!submission || !exam) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-800">Results not found</h2>
        <button
          onClick={() => navigate('/dashboard')}
          className="mt-4 px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }
  
  const totalPoints = exam.questions.reduce((sum: number, q: any) => sum + q.points, 0);
  const scorePercentage = submission.score ? (submission.score / totalPoints) * 100 : 0;
  const scoreColor = 
    scorePercentage >= 85 ? 'text-green-600' : 
    scorePercentage >= 70 ? 'text-blue-600' : 
    scorePercentage >= 50 ? 'text-amber-600' : 
    'text-red-600';
  
  return (
    <div className="max-w-4xl mx-auto">
      <Link to="/dashboard" className="inline-flex items-center text-blue-700 hover:text-blue-800 mb-6">
        <ArrowLeft size={16} className="mr-1" />
        Back to Dashboard
      </Link>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-lg shadow-md p-6 mb-6"
      >
        <h1 className="text-2xl font-bold text-gray-900 mb-2">{exam.title}</h1>
        <p className="text-gray-600 mb-6">{exam.description}</p>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between border-t border-b border-gray-100 py-4 mb-6">
          <div className="flex flex-col space-y-2 mb-4 md:mb-0">
            {submission.score !== undefined ? (
              <>
                <div className="flex items-center">
                  <Award size={20} className={`mr-2 ${scoreColor}`} />
                  <span className="text-xl font-bold">
                    Score: <span className={scoreColor}>{submission.score} / {totalPoints}</span>
                  </span>
                </div>
                <p className="text-gray-600 text-sm">
                  {scorePercentage}% - {
                    scorePercentage >= 85 ? 'Excellent!' : 
                    scorePercentage >= 70 ? 'Good job!' : 
                    scorePercentage >= 50 ? 'Passed' : 
                    'Needs improvement'
                  }
                </p>
              </>
            ) : (
              <div className="flex items-center text-amber-600">
                <AlertCircle size={20} className="mr-2" />
                <span className="font-medium">Awaiting Grading</span>
              </div>
            )}
          </div>
          
          <button 
            className="flex items-center px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700 transition-colors duration-200"
          >
            <Download size={16} className="mr-2" />
            Download Results
          </button>
        </div>
        
        <div className="space-y-8">
          {exam.questions.map((question: any, index: number) => {
            const userAnswer = submission.answers[question.id];
            const isCorrect = 
              question.type !== 'essay' && 
              (
                question.type === 'short-answer' 
                  ? userAnswer && question.correctAnswer && 
                    userAnswer.toLowerCase() === question.correctAnswer.toLowerCase()
                  : userAnswer === question.correctAnswer
              );
            
            return (
              <div key={question.id} className="border border-gray-100 rounded-lg p-5">
                <div className="flex items-start mb-4">
                  <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-800 text-xs flex items-center justify-center font-bold mr-2 mt-1">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{question.text}</h3>
                    <div className="mt-1 flex items-center">
                      <span className="text-sm text-gray-500 mr-3 capitalize">{question.type}</span>
                      <span className="text-sm text-gray-500">{question.points} points</span>
                    </div>
                  </div>
                </div>
                
                <div className="ml-8">
                  {/* Multiple choice or True/False display */}
                  {(question.type === 'multiple-choice' || question.type === 'true-false') && (
                    <div className="space-y-2">
                      {question.options?.map((option: string) => (
                        <div 
                          key={option}
                          className={`flex items-center p-2.5 rounded-md ${
                            option === question.correctAnswer && option === userAnswer
                              ? 'bg-green-50 border border-green-100'
                              : option === question.correctAnswer
                              ? 'bg-blue-50 border border-blue-100'
                              : option === userAnswer
                              ? 'bg-red-50 border border-red-100'
                              : 'bg-gray-50 border border-gray-100'
                          }`}
                        >
                          {option === question.correctAnswer && option === userAnswer && (
                            <CheckCircle size={18} className="text-green-600 mr-2 flex-shrink-0" />
                          )}
                          {option === question.correctAnswer && option !== userAnswer && (
                            <CheckCircle size={18} className="text-blue-600 mr-2 flex-shrink-0" />
                          )}
                          {option !== question.correctAnswer && option === userAnswer && (
                            <XCircle size={18} className="text-red-600 mr-2 flex-shrink-0" />
                          )}
                          <span className={`${
                            option === question.correctAnswer && option === userAnswer
                              ? 'text-green-700'
                              : option === question.correctAnswer
                              ? 'text-blue-700'
                              : option === userAnswer
                              ? 'text-red-700'
                              : 'text-gray-700'
                          }`}>
                            {option}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Short answer display */}
                  {question.type === 'short-answer' && (
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-medium text-gray-700 mb-1">Your Answer:</h4>
                        <div className={`p-3 rounded-md ${
                          isCorrect
                            ? 'bg-green-50 border border-green-100 text-green-700'
                            : 'bg-red-50 border border-red-100 text-red-700'
                        }`}>
                          {userAnswer || <span className="text-gray-400 italic">No answer provided</span>}
                        </div>
                      </div>
                      
                      {!isCorrect && (
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 mb-1">Correct Answer:</h4>
                          <div className="p-3 bg-blue-50 border border-blue-100 rounded-md text-blue-700">
                            {question.correctAnswer}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Essay display */}
                  {question.type === 'essay' && (
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 mb-1">Your Response:</h4>
                      <div className="p-3 bg-gray-50 border border-gray-100 rounded-md text-gray-700 whitespace-pre-wrap">
                        {userAnswer || <span className="text-gray-400 italic">No response provided</span>}
                      </div>
                      
                      <div className="mt-3 text-amber-600 flex items-center">
                        <AlertCircle size={16} className="mr-1" />
                        <span className="text-sm">Manual grading required</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};

export default ResultsPage;