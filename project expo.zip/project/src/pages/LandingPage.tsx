import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Award, Shield, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

const LandingPage: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <div className="text-2xl font-bold text-blue-800">ExamMaster</div>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <Link
                to="/dashboard"
                className="px-4 py-2 bg-blue-800 hover:bg-blue-700 text-white rounded-md transition-colors duration-200"
              >
                Dashboard
              </Link>
            ) : (
              <>
                <Link
                  to="/login"
                  className="px-4 py-2 text-blue-800 hover:bg-blue-50 rounded-md transition-colors duration-200"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 bg-blue-800 hover:bg-blue-700 text-white rounded-md transition-colors duration-200"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 to-blue-700 text-white py-16 lg:py-24">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl lg:text-5xl font-bold mb-4">
                Create, Deliver, and Grade Exams with Ease
              </h1>
              <p className="text-blue-100 text-lg mb-8">
                ExamMaster provides a secure and intuitive platform for creating online exams,
                delivering them to students, and automatically grading responses.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to={isAuthenticated ? "/dashboard" : "/register"}
                  className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-blue-900 font-medium rounded-md flex items-center justify-center"
                >
                  Get Started
                  <ArrowRight size={18} className="ml-2" />
                </Link>
                <Link
                  to="#features"
                  className="px-6 py-3 bg-blue-800 hover:bg-blue-700 text-white font-medium rounded-md flex items-center justify-center"
                >
                  Learn More
                </Link>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="hidden md:block"
            >
              <div className="relative bg-white p-6 rounded-lg shadow-xl">
                <div className="absolute -top-2 -right-2 bg-amber-500 text-blue-900 font-bold text-xs px-2 py-1 rounded">
                  PREVIEW
                </div>
                <h3 className="text-blue-800 font-semibold mb-4">JavaScript Fundamentals</h3>
                <div className="space-y-4">
                  <div className="p-3 bg-gray-50 rounded-md">
                    <p className="text-gray-800 font-medium">1. Which of the following is not a JavaScript data type?</p>
                    <div className="mt-3 space-y-2 text-sm">
                      <div className="flex items-center">
                        <input type="radio" id="opt1" name="q1" className="mr-2" />
                        <label htmlFor="opt1">String</label>
                      </div>
                      <div className="flex items-center">
                        <input type="radio" id="opt2" name="q1" className="mr-2" />
                        <label htmlFor="opt2">Character</label>
                      </div>
                      <div className="flex items-center">
                        <input type="radio" id="opt3" name="q1" className="mr-2" />
                        <label htmlFor="opt3">Boolean</label>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button className="text-sm bg-blue-800 text-white px-3 py-1 rounded-md">
                      Next Question
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Powerful Features</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Everything you need to create professional online exams and assess student knowledge effectively.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-100"
            >
              <div className="text-blue-800 mb-4">
                <Clock size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Timed Examinations</h3>
              <p className="text-gray-600">
                Set time limits for exams with automatic submission when time expires.
                Students see real-time countdown timers to manage their progress.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-100"
            >
              <div className="text-blue-800 mb-4">
                <CheckCircle size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Auto Grading</h3>
              <p className="text-gray-600">
                Multiple choice and true/false questions are graded instantly,
                providing immediate feedback to students and saving instructor time.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-100"
            >
              <div className="text-blue-800 mb-4">
                <Shield size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Secure Environment</h3>
              <p className="text-gray-600">
                Anti-cheating measures like random question ordering, 
                time monitoring, and browser focus detection ensure exam integrity.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-100"
            >
              <div className="text-blue-800 mb-4">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Detailed Analytics</h3>
              <p className="text-gray-600">
                Comprehensive reporting on student performance, question difficulty,
                and time spent helps instructors improve their teaching methods.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-100 md:col-span-2 lg:col-span-1"
            >
              <div className="text-blue-800 mb-4">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Multiple Question Types</h3>
              <p className="text-gray-600">
                Support for various question formats including multiple choice,
                true/false, short answer, and essay questions to test different skills.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-50 py-16">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Join thousands of educators who have already improved their testing process.
          </p>
          <Link
            to={isAuthenticated ? "/dashboard" : "/register"}
            className="px-8 py-3 bg-blue-800 hover:bg-blue-700 text-white font-medium rounded-md inline-flex items-center"
          >
            Create Your First Exam
            <ArrowRight size={18} className="ml-2" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="text-xl font-bold">ExamMaster</div>
              <p className="text-gray-400 text-sm mt-1">© 2025 ExamMaster. All rights reserved.</p>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;