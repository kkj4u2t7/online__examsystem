import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, Plus, Save, ArrowLeft, ArrowRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam, Question, Exam } from '../../contexts/ExamContext';
import { motion } from 'framer-motion';

type QuestionType = 'multiple-choice' | 'true-false' | 'short-answer' | 'essay';

const CreateExamPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { createExam } = useExam();
  
  const [step, setStep] = useState<'info' | 'questions' | 'review'>('info');
  
  // Basic exam information
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState(60); // Default 60 minutes
  
  // Questions
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<Question>({
    id: '',
    type: 'multiple-choice',
    text: '',
    options: ['', '', '', ''],
    correctAnswer: '',
    points: 10
  });
  
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Navigate through wizard steps
  const goToQuestions = () => {
    if (!title || !description || !duration) {
      setError('Please fill in all exam details');
      return;
    }
    setError('');
    setStep('questions');
  };

  const goToReview = () => {
    if (questions.length === 0) {
      setError('Please add at least one question');
      return;
    }
    setError('');
    setStep('review');
  };
  
  const goBack = () => {
    if (step === 'questions') {
      setStep('info');
    } else if (step === 'review') {
      setStep('questions');
    }
  };

  // Handle question type change
  const handleQuestionTypeChange = (type: QuestionType) => {
    if (type === 'multiple-choice') {
      setCurrentQuestion({
        ...currentQuestion,
        type,
        options: ['', '', '', ''],
        correctAnswer: ''
      });
    } else if (type === 'true-false') {
      setCurrentQuestion({
        ...currentQuestion,
        type,
        options: ['True', 'False'],
        correctAnswer: ''
      });
    } else {
      setCurrentQuestion({
        ...currentQuestion,
        type,
        options: undefined,
        correctAnswer: type === 'short-answer' ? '' : undefined
      });
    }
  };

  // Add/update option for multiple choice questions
  const handleOptionChange = (index: number, value: string) => {
    if (!currentQuestion.options) return;
    
    const newOptions = [...currentQuestion.options];
    newOptions[index] = value;
    setCurrentQuestion({ ...currentQuestion, options: newOptions });
  };

  // Add a new question
  const addQuestion = () => {
    if (!currentQuestion.text) {
      setError('Question text is required');
      return;
    }
    
    if (currentQuestion.type === 'multiple-choice' && 
        (!currentQuestion.options || !currentQuestion.options.every(opt => opt))) {
      setError('All options must be filled in');
      return;
    }
    
    if ((currentQuestion.type === 'multiple-choice' || currentQuestion.type === 'true-false') && 
        !currentQuestion.correctAnswer) {
      setError('Please select the correct answer');
      return;
    }
    
    if (currentQuestion.type === 'short-answer' && !currentQuestion.correctAnswer) {
      setError('Please provide the correct answer');
      return;
    }
    
    setError('');
    
    const newQuestion = {
      ...currentQuestion,
      id: Math.random().toString(36).substring(2, 9)
    };
    
    setQuestions([...questions, newQuestion]);
    
    // Reset current question
    setCurrentQuestion({
      id: '',
      type: 'multiple-choice',
      text: '',
      options: ['', '', '', ''],
      correctAnswer: '',
      points: 10
    });
  };

  // Remove a question
  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  // Submit the exam
  const handleSubmit = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      const newExam: Omit<Exam, 'id' | 'createdAt'> = {
        title,
        description,
        duration,
        questions,
        createdBy: user.id,
        isPublished: true
      };
      
      await createExam(newExam);
      navigate('/dashboard');
    } catch (error) {
      setError('Failed to create exam. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button
        onClick={goBack}
        className={`mb-6 flex items-center text-blue-700 hover:text-blue-800 ${step === 'info' ? 'invisible' : ''}`}
      >
        <ArrowLeft size={16} className="mr-1" />
        Back
      </button>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Create New Exam</h1>
        <p className="text-gray-600">
          {step === 'info' ? 'Enter basic exam information' : 
           step === 'questions' ? 'Add questions to your exam' : 
           'Review your exam before publishing'}
        </p>
      </div>

      {/* Progress indicator */}
      <div className="mb-8">
        <div className="flex items-center">
          <div className={`flex items-center justify-center h-8 w-8 rounded-full ${step === 'info' ? 'bg-blue-800 text-white' : 'bg-blue-800 text-white'}`}>
            1
          </div>
          <div className={`flex-1 h-1 mx-2 ${step === 'info' ? 'bg-gray-200' : 'bg-blue-800'}`}></div>
          <div className={`flex items-center justify-center h-8 w-8 rounded-full ${step === 'questions' || step === 'review' ? 'bg-blue-800 text-white' : 'bg-gray-200 text-gray-600'}`}>
            2
          </div>
          <div className={`flex-1 h-1 mx-2 ${step === 'review' ? 'bg-blue-800' : 'bg-gray-200'}`}></div>
          <div className={`flex items-center justify-center h-8 w-8 rounded-full ${step === 'review' ? 'bg-blue-800 text-white' : 'bg-gray-200 text-gray-600'}`}>
            3
          </div>
        </div>
        <div className="flex justify-between mt-2 text-xs text-gray-600">
          <span>Basic Information</span>
          <span>Questions</span>
          <span>Review &amp; Publish</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
          {error}
        </div>
      )}

      {/* Step 1: Basic Information */}
      {step === 'info' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <div className="mb-6">
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
              Exam Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., Introduction to JavaScript"
            />
          </div>
          
          <div className="mb-6">
            <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe what this exam covers..."
            />
          </div>
          
          <div className="mb-6">
            <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
              Duration (minutes)
            </label>
            <input
              type="number"
              id="duration"
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value))}
              min={1}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={goToQuestions}
              className="px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700 flex items-center"
            >
              Next: Add Questions
              <ArrowRight size={16} className="ml-1" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Questions */}
      {step === 'questions' && (
        <div>
          {/* Added questions list */}
          {questions.length > 0 && (
            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Questions Added ({questions.length})</h3>
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4 space-y-4">
                {questions.map((q, index) => (
                  <div key={q.id} className="border border-gray-100 rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center">
                          <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-800 text-xs flex items-center justify-center font-bold mr-2">
                            {index + 1}
                          </span>
                          <span className="font-medium text-gray-900">{q.text}</span>
                        </div>
                        <div className="mt-2 ml-8">
                          <span className="text-xs text-gray-500 mr-3 capitalize">{q.type}</span>
                          <span className="text-xs text-gray-500">{q.points} points</span>
                        </div>
                      </div>
                      <button
                        onClick={() => removeQuestion(q.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add new question form */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Question</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Question Type
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button
                  type="button"
                  onClick={() => handleQuestionTypeChange('multiple-choice')}
                  className={`px-4 py-2 rounded-md text-sm ${
                    currentQuestion.type === 'multiple-choice'
                      ? 'bg-blue-800 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Multiple Choice
                </button>
                <button
                  type="button"
                  onClick={() => handleQuestionTypeChange('true-false')}
                  className={`px-4 py-2 rounded-md text-sm ${
                    currentQuestion.type === 'true-false'
                      ? 'bg-blue-800 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  True/False
                </button>
                <button
                  type="button"
                  onClick={() => handleQuestionTypeChange('short-answer')}
                  className={`px-4 py-2 rounded-md text-sm ${
                    currentQuestion.type === 'short-answer'
                      ? 'bg-blue-800 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Short Answer
                </button>
                <button
                  type="button"
                  onClick={() => handleQuestionTypeChange('essay')}
                  className={`px-4 py-2 rounded-md text-sm ${
                    currentQuestion.type === 'essay'
                      ? 'bg-blue-800 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  Essay
                </button>
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="question-text" className="block text-sm font-medium text-gray-700 mb-1">
                Question Text
              </label>
              <textarea
                id="question-text"
                value={currentQuestion.text}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, text: e.target.value })}
                rows={2}
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your question here..."
              />
            </div>
            
            {/* Options for multiple choice */}
            {currentQuestion.type === 'multiple-choice' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Options
                </label>
                <div className="space-y-2">
                  {currentQuestion.options?.map((option, index) => (
                    <div key={index} className="flex items-center">
                      <input
                        type="radio"
                        id={`option-${index}`}
                        name="correct-answer"
                        checked={currentQuestion.correctAnswer === option}
                        onChange={() => setCurrentQuestion({ ...currentQuestion, correctAnswer: option })}
                        className="mr-2"
                      />
                      <input
                        type="text"
                        value={option}
                        onChange={(e) => handleOptionChange(index, e.target.value)}
                        className="flex-1 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder={`Option ${index + 1}`}
                      />
                    </div>
                  ))}
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  Select the correct answer by clicking the radio button
                </p>
              </div>
            )}
            
            {/* Options for true/false */}
            {currentQuestion.type === 'true-false' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Correct Answer
                </label>
                <div className="flex space-x-4">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="true-false"
                      value="True"
                      checked={currentQuestion.correctAnswer === 'True'}
                      onChange={() => setCurrentQuestion({ ...currentQuestion, correctAnswer: 'True' })}
                      className="mr-2"
                    />
                    True
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="true-false"
                      value="False"
                      checked={currentQuestion.correctAnswer === 'False'}
                      onChange={() => setCurrentQuestion({ ...currentQuestion, correctAnswer: 'False' })}
                      className="mr-2"
                    />
                    False
                  </label>
                </div>
              </div>
            )}
            
            {/* Correct answer for short answer */}
            {currentQuestion.type === 'short-answer' && (
              <div className="mb-4">
                <label htmlFor="correct-answer" className="block text-sm font-medium text-gray-700 mb-1">
                  Correct Answer
                </label>
                <input
                  type="text"
                  id="correct-answer"
                  value={currentQuestion.correctAnswer as string || ''}
                  onChange={(e) => setCurrentQuestion({ ...currentQuestion, correctAnswer: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="The correct answer"
                />
              </div>
            )}
            
            <div className="mb-4">
              <label htmlFor="points" className="block text-sm font-medium text-gray-700 mb-1">
                Points
              </label>
              <input
                type="number"
                id="points"
                value={currentQuestion.points}
                onChange={(e) => setCurrentQuestion({ ...currentQuestion, points: parseInt(e.target.value) })}
                min={1}
                className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={addQuestion}
                className="px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700 flex items-center"
              >
                <Plus size={16} className="mr-1" />
                Add Question
              </button>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end">
            <button
              onClick={goToReview}
              className="px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700 flex items-center"
            >
              Next: Review Exam
              <ArrowRight size={16} className="ml-1" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Review */}
      {step === 'review' && (
        <div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Exam Overview</h3>
            
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-medium text-gray-700">Title</h4>
                <p className="text-gray-900">{title}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700">Description</h4>
                <p className="text-gray-900">{description}</p>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Duration</h4>
                  <p className="text-gray-900">{duration} minutes</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Total Questions</h4>
                  <p className="text-gray-900">{questions.length}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Total Points</h4>
                  <p className="text-gray-900">{questions.reduce((sum, q) => sum + q.points, 0)}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Questions Preview</h3>
            
            <div className="space-y-6">
              {questions.map((q, index) => (
                <div key={q.id} className="border border-gray-100 rounded-md p-4">
                  <div className="flex items-start">
                    <span className="h-6 w-6 rounded-full bg-blue-100 text-blue-800 text-xs flex items-center justify-center font-bold mr-2 mt-0.5">
                      {index + 1}
                    </span>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{q.text}</p>
                      
                      <div className="mt-2 space-y-1">
                        {q.type === 'multiple-choice' && q.options?.map((option, optIndex) => (
                          <div key={optIndex} className="flex items-center">
                            <div className={`h-4 w-4 rounded-full mr-2 ${option === q.correctAnswer ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                            <span className={option === q.correctAnswer ? 'text-green-700 font-medium' : 'text-gray-700'}>
                              {option}
                            </span>
                          </div>
                        ))}
                        
                        {q.type === 'true-false' && (
                          <div className="flex space-x-4">
                            <div className="flex items-center">
                              <div className={`h-4 w-4 rounded-full mr-2 ${q.correctAnswer === 'True' ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                              <span className={q.correctAnswer === 'True' ? 'text-green-700 font-medium' : 'text-gray-700'}>
                                True
                              </span>
                            </div>
                            <div className="flex items-center">
                              <div className={`h-4 w-4 rounded-full mr-2 ${q.correctAnswer === 'False' ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                              <span className={q.correctAnswer === 'False' ? 'text-green-700 font-medium' : 'text-gray-700'}>
                                False
                              </span>
                            </div>
                          </div>
                        )}
                        
                        {q.type === 'short-answer' && (
                          <div className="mt-2">
                            <span className="text-sm text-gray-600">Correct answer: </span>
                            <span className="text-green-700 font-medium">{q.correctAnswer}</span>
                          </div>
                        )}
                        
                        {q.type === 'essay' && (
                          <div className="mt-2 italic text-gray-500">
                            Requires manual grading
                          </div>
                        )}
                      </div>
                      
                      <div className="mt-2 text-xs text-gray-500">
                        {q.points} points
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSubmit}
              disabled={loading}
              className={`px-4 py-2 rounded-md flex items-center ${
                loading
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-blue-800 hover:bg-blue-700 text-white'
              }`}
            >
              {loading ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating Exam...
                </span>
              ) : (
                <>
                  <Save size={16} className="mr-1" />
                  Publish Exam
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateExamPage;