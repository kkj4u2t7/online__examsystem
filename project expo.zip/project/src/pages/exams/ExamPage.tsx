import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Clock, AlertTriangle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam, Question, ExamSubmission } from '../../contexts/ExamContext';
import { motion, AnimatePresence } from 'framer-motion';

const ExamPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getExam, submitExam } = useExam();
  
  const [exam, setExam] = useState(id ? getExam(id) : undefined);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [key: string]: string | string[] }>({});
  const [timeLeft, setTimeLeft] = useState(exam ? exam.duration * 60 : 0);
  const [examStarted, setExamStarted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [warningShown, setWarningShown] = useState(false);
  
  // Format remaining time
  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return [
      hrs > 0 ? String(hrs).padStart(2, '0') : null,
      String(mins).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].filter(Boolean).join(':');
  };
  
  // Navigate between questions
  const goToNextQuestion = () => {
    if (currentQuestionIndex < (exam?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };
  
  const goToPrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  // Handle answer changes
  const handleAnswerChange = (question: Question, answer: string | string[]) => {
    setAnswers({ ...answers, [question.id]: answer });
  };
  
  // Start the exam
  const handleStartExam = () => {
    setExamStarted(true);
  };
  
  // Submit the exam
  const handleSubmitExam = async () => {
    if (!user || !exam || !id) return;
    
    setSubmitting(true);
    
    try {
      const now = new Date().toISOString();
      const startTime = new Date(Date.now() - (exam.duration * 60 - timeLeft) * 1000).toISOString();
      
      const submission: Omit<ExamSubmission, 'id'> = {
        examId: id,
        userId: user.id,
        answers,
        startTime,
        endTime: now,
        isGraded: false
      };
      
      await submitExam(submission);
      navigate('/dashboard');
    } catch (error) {
      console.error('Error submitting exam:', error);
    } finally {
      setSubmitting(false);
    }
  };
  
  // Timer effect
  useEffect(() => {
    if (!examStarted || !exam) return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmitExam();
          return 0;
        }
        
        // Show warning when 5 minutes remaining
        if (prev === 300 && !warningShown) {
          setWarningShown(true);
        }
        
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [examStarted, exam]);
  
  // Set up exam
  useEffect(() => {
    if (id) {
      const examData = getExam(id);
      setExam(examData);
      
      if (examData) {
        setTimeLeft(examData.duration * 60);
      }
    }
  }, [id, getExam]);
  
  if (!exam) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-800">Exam not found</h2>
        <button
          onClick={() => navigate('/dashboard')}
          className="mt-4 px-4 py-2 bg-blue-800 text-white rounded-md hover:bg-blue-700"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }
  
  const currentQuestion = exam.questions[currentQuestionIndex];
  const answeredCount = Object.keys(answers).length;
  const progressPercentage = (answeredCount / exam.questions.length) * 100;
  
  return (
    <div className="max-w-4xl mx-auto">
      {!examStarted ? (
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">{exam.title}</h1>
          <p className="text-gray-600 mb-6">{exam.description}</p>
          
          <div className="bg-blue-50 border border-blue-100 rounded-md p-4 mb-6">
            <h2 className="text-lg font-semibold text-blue-800 mb-2">Exam Instructions</h2>
            <ul className="space-y-2 text-blue-700">
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                This exam has {exam.questions.length} questions and is worth {exam.questions.reduce((sum, q) => sum + q.points, 0)} points.
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                You have {exam.duration} minutes to complete the exam.
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                Your answers are saved automatically as you progress.
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                You can navigate between questions using the previous and next buttons.
              </li>
              <li className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                The exam will be automatically submitted when the time expires.
              </li>
            </ul>
          </div>
          
          <div className="mt-8 flex justify-center">
            <button
              onClick={handleStartExam}
              className="px-6 py-3 bg-blue-800 text-white rounded-md hover:bg-blue-700 transition-colors duration-200 font-medium"
            >
              Start Exam
            </button>
          </div>
        </div>
      ) : (
        <div>
          {/* Header with timer and progress */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4 mb-6 sticky top-0 z-10">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <h1 className="text-xl font-bold text-gray-900 mb-2 sm:mb-0">{exam.title}</h1>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center">
                  <Clock size={18} className={`mr-1 ${timeLeft < 300 ? 'text-red-600' : 'text-blue-800'}`} />
                  <span className={`font-mono font-medium ${timeLeft < 300 ? 'text-red-600' : 'text-blue-800'}`}>
                    {formatTime(timeLeft)}
                  </span>
                </div>
                
                <div className="hidden sm:flex items-center">
                  <span className="text-sm text-gray-600 mr-2">
                    {answeredCount} of {exam.questions.length}
                  </span>
                  <div className="w-24 h-2 bg-gray-200 rounded-full">
                    <div
                      className="h-2 bg-blue-800 rounded-full"
                      style={{ width: `${progressPercentage}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Mobile progress bar */}
            <div className="sm:hidden mt-2">
              <div className="flex justify-between text-xs text-gray-600 mb-1">
                <span>Question {currentQuestionIndex + 1} of {exam.questions.length}</span>
                <span>{answeredCount} answered</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full">
                <div
                  className="h-2 bg-blue-800 rounded-full"
                  style={{ width: `${progressPercentage}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          {/* Warning modal for time running out */}
          <AnimatePresence>
            {warningShown && timeLeft < 300 && (
              <motion.div
                initial={{ opacity: 0, y: -50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -50 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4"
              >
                <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setWarningShown(false)}></div>
                <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full relative">
                  <div className="flex items-start">
                    <div className="mr-4 text-red-600">
                      <AlertTriangle size={36} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 mb-2">Time Running Out!</h3>
                      <p className="text-gray-600 mb-4">
                        You have less than 5 minutes remaining. The exam will be automatically submitted when time expires.
                      </p>
                      <button
                        onClick={() => setWarningShown(false)}
                        className="w-full px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                      >
                        Continue Exam
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Question display */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="mb-6">
              <div className="flex items-center mb-4">
                <span className="h-8 w-8 rounded-full bg-blue-100 text-blue-800 text-sm flex items-center justify-center font-bold mr-2">
                  {currentQuestionIndex + 1}
                </span>
                <span className="text-sm text-gray-600">
                  {currentQuestion.points} points
                </span>
              </div>
              
              <h2 className="text-xl font-medium text-gray-900 mb-6">{currentQuestion.text}</h2>
              
              {/* Multiple choice */}
              {currentQuestion.type === 'multiple-choice' && (
                <div className="space-y-3">
                  {currentQuestion.options?.map((option, index) => (
                    <label
                      key={index}
                      className={`flex items-center p-3 border rounded-md cursor-pointer transition-colors ${
                        answers[currentQuestion.id] === option
                          ? 'border-blue-800 bg-blue-50'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name={`question-${currentQuestion.id}`}
                        value={option}
                        checked={answers[currentQuestion.id] === option}
                        onChange={() => handleAnswerChange(currentQuestion, option)}
                        className="h-4 w-4 text-blue-800 focus:ring-blue-500 border-gray-300"
                      />
                      <span className="ml-2 text-gray-800">{option}</span>
                    </label>
                  ))}
                </div>
              )}
              
              {/* True/False */}
              {currentQuestion.type === 'true-false' && (
                <div className="space-y-3">
                  {['True', 'False'].map((option) => (
                    <label
                      key={option}
                      className={`flex items-center p-3 border rounded-md cursor-pointer transition-colors ${
                        answers[currentQuestion.id] === option
                          ? 'border-blue-800 bg-blue-50'
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name={`question-${currentQuestion.id}`}
                        value={option}
                        checked={answers[currentQuestion.id] === option}
                        onChange={() => handleAnswerChange(currentQuestion, option)}
                        className="h-4 w-4 text-blue-800 focus:ring-blue-500 border-gray-300"
                      />
                      <span className="ml-2 text-gray-800">{option}</span>
                    </label>
                  ))}
                </div>
              )}
              
              {/* Short answer */}
              {currentQuestion.type === 'short-answer' && (
                <div>
                  <input
                    type="text"
                    value={(answers[currentQuestion.id] as string) || ''}
                    onChange={(e) => handleAnswerChange(currentQuestion, e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your answer"
                  />
                </div>
              )}
              
              {/* Essay */}
              {currentQuestion.type === 'essay' && (
                <div>
                  <textarea
                    value={(answers[currentQuestion.id] as string) || ''}
                    onChange={(e) => handleAnswerChange(currentQuestion, e.target.value)}
                    rows={8}
                    className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your answer"
                  />
                </div>
              )}
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex justify-between mb-8">
            <button
              onClick={goToPrevQuestion}
              disabled={currentQuestionIndex === 0}
              className={`px-4 py-2 flex items-center rounded-md ${
                currentQuestionIndex === 0
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              <ChevronLeft size={18} className="mr-1" />
              Previous
            </button>
            
            <div className="flex items-center">
              {currentQuestionIndex === exam.questions.length - 1 ? (
                <button
                  onClick={handleSubmitExam}
                  disabled={submitting}
                  className={`px-6 py-2 rounded-md ${
                    submitting
                      ? 'bg-gray-400 text-white cursor-not-allowed'
                      : 'bg-blue-800 text-white hover:bg-blue-700'
                  }`}
                >
                  {submitting ? 'Submitting...' : 'Submit Exam'}
                </button>
              ) : (
                <button
                  onClick={goToNextQuestion}
                  className="px-4 py-2 bg-blue-800 text-white flex items-center rounded-md hover:bg-blue-700"
                >
                  Next
                  <ChevronRight size={18} className="ml-1" />
                </button>
              )}
            </div>
          </div>
          
          {/* Question quick navigation */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-4 mb-8">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Question Navigation</h3>
            <div className="flex flex-wrap gap-2">
              {exam.questions.map((q, index) => (
                <button
                  key={q.id}
                  onClick={() => setCurrentQuestionIndex(index)}
                  className={`h-8 w-8 flex items-center justify-center rounded-md text-sm font-medium ${
                    index === currentQuestionIndex
                      ? 'bg-blue-800 text-white'
                      : answers[q.id]
                      ? 'bg-green-100 text-green-800 border border-green-200'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExamPage;