import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, LogOut, User, Bell } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { motion } from 'framer-motion';

interface NavbarProps {
  toggleSidebar: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-blue-800 text-white shadow-md px-4 py-3 flex justify-between items-center">
      <div className="flex items-center space-x-4">
        <button 
          onClick={toggleSidebar}
          className="p-1 rounded-full hover:bg-blue-700 transition-colors duration-200"
          aria-label="Toggle sidebar"
        >
          <Menu size={24} />
        </button>
        <Link to="/dashboard" className="text-xl font-bold tracking-tight flex items-center">
          <span className="hidden sm:inline">ExamMaster</span>
          <span className="sm:hidden">EM</span>
        </Link>
      </div>

      <div className="flex items-center space-x-4">
        <button 
          className="p-2 rounded-full hover:bg-blue-700 transition-colors duration-200 relative"
          aria-label="Notifications"
        >
          <Bell size={20} />
          <span className="absolute top-0 right-0 h-2 w-2 bg-amber-500 rounded-full"></span>
        </button>
        
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center space-x-2 rounded-full hover:bg-blue-700 px-2 py-1 transition-colors duration-200"
          >
            <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-sm font-medium">
              {user?.name.charAt(0)}
            </div>
            <span className="hidden md:inline">{user?.name}</span>
          </button>

          {profileOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 text-gray-800"
            >
              <button
                className="flex items-center w-full px-4 py-2 text-sm hover:bg-gray-100"
                onClick={() => {
                  setProfileOpen(false);
                }}
              >
                <User size={16} className="mr-2" />
                Profile
              </button>
              <button
                className="flex items-center w-full px-4 py-2 text-sm hover:bg-gray-100 text-red-600"
                onClick={() => {
                  setProfileOpen(false);
                  handleLogout();
                }}
              >
                <LogOut size={16} className="mr-2" />
                Logout
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;