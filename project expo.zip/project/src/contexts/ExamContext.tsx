import React, { createContext, useContext, useState } from 'react';

export interface Question {
  id: string;
  type: 'multiple-choice' | 'true-false' | 'short-answer' | 'essay';
  text: string;
  options?: string[];
  correctAnswer?: string | string[];
  points: number;
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  questions: Question[];
  createdBy: string;
  createdAt: string;
  isPublished: boolean;
}

export interface ExamSubmission {
  id: string;
  examId: string;
  userId: string;
  answers: { [questionId: string]: string | string[] };
  startTime: string;
  endTime: string;
  score?: number;
  isGraded: boolean;
}

interface ExamContextType {
  exams: Exam[];
  submissions: ExamSubmission[];
  createExam: (exam: Omit<Exam, 'id' | 'createdAt'>) => Promise<Exam>;
  getExam: (id: string) => Exam | undefined;
  submitExam: (submission: Omit<ExamSubmission, 'id'>) => Promise<ExamSubmission>;
  getUserExams: (userId: string) => Exam[];
  getUserSubmissions: (userId: string) => ExamSubmission[];
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export const useExam = () => {
  const context = useContext(ExamContext);
  if (context === undefined) {
    throw new Error('useExam must be used within an ExamProvider');
  }
  return context;
};

// Mock data
const mockExams: Exam[] = [
  {
    id: '1',
    title: 'Introduction to JavaScript',
    description: 'Test your knowledge of JavaScript fundamentals.',
    duration: 60,
    questions: [
      {
        id: '1a',
        type: 'multiple-choice',
        text: 'Which of the following is NOT a JavaScript data type?',
        options: ['String', 'Number', 'Boolean', 'Character'],
        correctAnswer: 'Character',
        points: 10
      },
      {
        id: '1b',
        type: 'true-false',
        text: 'JavaScript is a statically typed language.',
        options: ['True', 'False'],
        correctAnswer: 'False',
        points: 5
      },
      {
        id: '1c',
        type: 'short-answer',
        text: 'What does DOM stand for?',
        correctAnswer: 'Document Object Model',
        points: 15
      }
    ],
    createdBy: '1',
    createdAt: '2023-06-15T10:00:00Z',
    isPublished: true
  },
  {
    id: '2',
    title: 'React Fundamentals',
    description: 'A comprehensive examination of React core concepts.',
    duration: 90,
    questions: [
      {
        id: '2a',
        type: 'multiple-choice',
        text: 'Which hook is used to perform side effects in a function component?',
        options: ['useState', 'useEffect', 'useContext', 'useReducer'],
        correctAnswer: 'useEffect',
        points: 10
      },
      {
        id: '2b',
        type: 'essay',
        text: 'Explain the concept of React component lifecycle and how hooks have changed it.',
        points: 25
      }
    ],
    createdBy: '1',
    createdAt: '2023-07-20T11:30:00Z',
    isPublished: true
  }
];

const mockSubmissions: ExamSubmission[] = [
  {
    id: '1001',
    examId: '1',
    userId: '2',
    answers: {
      '1a': 'String',
      '1b': 'False',
      '1c': 'Document Object Model'
    },
    startTime: '2023-09-10T09:00:00Z',
    endTime: '2023-09-10T09:45:00Z',
    score: 20,
    isGraded: true
  }
];

export const ExamProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [exams, setExams] = useState<Exam[]>(mockExams);
  const [submissions, setSubmissions] = useState<ExamSubmission[]>(mockSubmissions);

  const createExam = async (examData: Omit<Exam, 'id' | 'createdAt'>): Promise<Exam> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newExam: Exam = {
      ...examData,
      id: Math.random().toString(36).substring(2, 9),
      createdAt: new Date().toISOString()
    };
    
    setExams(prevExams => [...prevExams, newExam]);
    return newExam;
  };

  const getExam = (id: string): Exam | undefined => {
    return exams.find(exam => exam.id === id);
  };

  const submitExam = async (submissionData: Omit<ExamSubmission, 'id'>): Promise<ExamSubmission> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const exam = exams.find(e => e.id === submissionData.examId);
    
    if (!exam) {
      throw new Error('Exam not found');
    }
    
    // Auto-grade objective questions
    let score = 0;
    let totalPoints = 0;
    
    exam.questions.forEach(question => {
      totalPoints += question.points;
      
      if (question.type === 'multiple-choice' || question.type === 'true-false') {
        const userAnswer = submissionData.answers[question.id];
        if (userAnswer === question.correctAnswer) {
          score += question.points;
        }
      } else if (question.type === 'short-answer') {
        const userAnswer = submissionData.answers[question.id];
        if (typeof userAnswer === 'string' && 
            typeof question.correctAnswer === 'string' && 
            userAnswer.toLowerCase() === question.correctAnswer.toLowerCase()) {
          score += question.points;
        }
      }
      // Essay questions need manual grading
    });
    
    const isGraded = !exam.questions.some(q => q.type === 'essay');
    
    const newSubmission: ExamSubmission = {
      ...submissionData,
      id: Math.random().toString(36).substring(2, 9),
      score: isGraded ? score : undefined,
      isGraded
    };
    
    setSubmissions(prevSubmissions => [...prevSubmissions, newSubmission]);
    return newSubmission;
  };

  const getUserExams = (userId: string): Exam[] => {
    // For students, return published exams they can take
    // For instructors, return exams they created
    return exams.filter(exam => 
      exam.isPublished || exam.createdBy === userId
    );
  };

  const getUserSubmissions = (userId: string): ExamSubmission[] => {
    return submissions.filter(submission => submission.userId === userId);
  };

  const value = {
    exams,
    submissions,
    createExam,
    getExam,
    submitExam,
    getUserExams,
    getUserSubmissions
  };

  return <ExamContext.Provider value={value}>{children}</ExamContext.Provider>;
};